package com.business;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsBeautyProductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsBeautyProductsApplication.class, args);
	}

}
